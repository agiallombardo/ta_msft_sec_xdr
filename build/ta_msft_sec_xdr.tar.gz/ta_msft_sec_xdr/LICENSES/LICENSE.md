# GNU GENERAL PUBLIC LICENSE

## Version 3, 29 June 2007

**Copyright (C) 2025 Anthony Giallombardo, NullQu LLC**  
Atlanta, Georgia, United States

Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

### Preamble

The GNU General Public License is a free, copyleft license for software and other kinds of works.

The licenses for most software and other practical works are designed to take away your freedom to share and change the works. By contrast, the GNU General Public License is intended to guarantee your freedom to share and change all versions of a program—to make sure it remains free software for all its users...

[Full license text continues at the GNU site](https://www.gnu.org/licenses/gpl-3.0.txt)
